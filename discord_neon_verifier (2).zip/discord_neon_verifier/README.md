# Discord OAuth2 Verifier + Neon (Windows)

This project runs the Discord bot and OAuth2 callback website on your Windows PC. Neon is used only for the hosted PostgreSQL database. No Vercel deployment is used.

## What it does

- `/setup` posts a verification panel in the configured Discord server.
- Members click **Verify / Join**, approve Discord OAuth2 (`identify` and `guilds.join`), and are added to the configured server.
- If configured, the bot applies the verified role.
- `!member @user` retries joining/role assignment for a user who previously authorized this server.
- `!stats` reports authorization and successful-join counts.
- OAuth access and refresh tokens are encrypted before being stored in Neon.

Only use this for members who knowingly click the verification link and authorize your Discord application. Do not use it to add people to servers without their consent.

## 1. Create the Discord application

1. Open the Discord Developer Portal: https://discord.com/developers/applications
2. Create an application.
3. Under **OAuth2**, copy the Client ID and Client Secret.
4. Under **Bot**, create a bot and copy its token.
5. Enable **Server Members Intent** and **Message Content Intent** under Bot -> Privileged Gateway Intents.
6. Invite the bot to your server with the `bot` and `applications.commands` scopes. Give it the permissions it needs to view/send messages and manage roles. The bot's highest role must be above the verified role.
7. In your application OAuth2 settings, you will add the callback URL after starting the tunnel.

Never share your bot token, client secret, or database URL.

## 2. Set up Neon

1. Create a project at https://neon.tech/
2. Copy the PostgreSQL connection string from the Neon dashboard.
3. The app creates its table automatically on first startup.

If you previously posted your Neon connection string or password somewhere public, rotate the database password before using it.

## 3. Configure the project

1. Rename `.env.example` to `.env`.
2. Fill in `BOT_TOKEN`, `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`, `GUILD_ID`, `VERIFIED_ROLE_ID`, and `DATABASE_URL`.
3. Generate an encryption key in Command Prompt from this project folder:

   `py -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"`

   Paste the output into `ENCRYPTION_KEY`.
4. Generate a Flask secret:

   `py -c "import secrets; print(secrets.token_urlsafe(48))"`

   Paste it into `FLASK_SECRET_KEY`.

To copy Discord IDs, enable Developer Mode in Discord settings, then right-click the server or role and choose **Copy ID**.

## 4. Create the public HTTPS callback

Discord requires an HTTPS redirect URL. Cloudflare Tunnel exposes your local web server without hosting the app on Vercel.

1. Install `cloudflared` for Windows from https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/.
2. Start `run.bat` once so Python installs dependencies and starts the local server/bot. If configuration is incomplete, stop it with Ctrl+C after installation; you can also install dependencies with `pip install -r requirements.txt`.
3. Run `start-tunnel.bat` in a second Command Prompt window.
4. Copy the generated `https://....trycloudflare.com` address.
5. Put it in `.env`:
   - `PUBLIC_BASE_URL=https://....trycloudflare.com`
   - `OAUTH_REDIRECT_URI=https://....trycloudflare.com/callback`
6. In Discord Developer Portal -> OAuth2 -> Redirects, add that exact callback URL, including `/callback`.
7. Restart `run.bat`.

A Quick Tunnel URL can change when restarted. If it changes, update both `.env` values and the Discord OAuth2 Redirects list.

## 5. Use it

1. Keep both the bot window and tunnel window running.
2. In your Discord server, run `/setup` (administrator permission required).
3. Members click **Verify / Join** and approve the Discord authorization screen.
4. Admins can use `!member @user` to retry for a user who has authorized the configured server.
5. Admins can use `!stats` to view totals.

## Important requirements / troubleshooting

- Your PC must be on, connected to the internet, and both windows must stay running. If the bot or tunnel stops, verification will be unavailable.
- The bot must already be in the configured server.
- The bot needs Manage Roles, and its top role must be above the verified role.
- `VERIFIED_ROLE_ID` may be left blank if you do not want automatic role assignment.
- `!member` and `!stats` are administrator-only.
- The bot uses the configured `GUILD_ID`; it will not add users to arbitrary servers.
- If you change your OAuth redirect URL, update it in both `.env` and the Developer Portal.
- Never upload `.env` or send its contents to anyone.

## Security notes

OAuth tokens are encrypted at rest in Neon using the Fernet key in `.env`. Keep that key backed up securely: losing it means the stored tokens cannot be decrypted. The Flask session secret protects the OAuth state cookie. Use a strong random value and keep `.env` private.
