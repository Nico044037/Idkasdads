@echo off
echo Starting Cloudflare Quick Tunnel to http://localhost:5000
echo Copy the https://...trycloudflare.com URL into .env as PUBLIC_BASE_URL
echo Set OAUTH_REDIRECT_URI to that URL plus /callback
echo Then add the exact callback URL in Discord Developer Portal -> OAuth2 -> Redirects.
cloudflared tunnel --url http://localhost:5000
pause
